"""Regression suite: one test per question in questions.yaml.

Run:
    pytest -v                          # full run against chat API + Neo4j
    pytest --no-api                    # only check ground-truth Cypher executes
    pytest --category fraud            # subset
    pytest --ids Q01,Q19,Q34           # specific questions
    pytest -n 4                        # parallel (pytest-xdist)

Environment:
    T2C_API_URL, T2C_API_KEY, NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD, NEO4J_DATABASE
"""
import time

import pytest

from harness import Question, ask_chat, compare


def test_question(q: Question, graph, results, no_api):
    # 1. ground truth
    t0 = time.perf_counter()
    try:
        want = graph.run(q.expected_cypher)
    except Exception as e:  # noqa: BLE001
        pytest.fail(f"{q.id}: ground-truth Cypher failed to execute - fix questions.yaml\n{q.expected_cypher}\n{e}")
    gt_latency = time.perf_counter() - t0

    if no_api:
        results.add(dict(id=q.id, category=q.category, question=q.question, passed=True,
                         detail=f"ground truth ok ({len(want)} rows)", latency_s=gt_latency))
        return

    # 2. ask the chat
    try:
        res = ask_chat(q.question)
    except Exception as e:  # noqa: BLE001
        results.add(dict(id=q.id, category=q.category, question=q.question, passed=False,
                         detail=f"API error: {e}", latency_s=0))
        pytest.fail(f"{q.id}: chat API error: {e}")

    # 3. get rows from the chat response (execute its Cypher if it only returned Cypher)
    got = res.rows
    exec_error = None
    if got is None and res.cypher:
        try:
            got = graph.run(res.cypher)
        except Exception as e:  # noqa: BLE001
            exec_error = str(e)
            got = []

    passed, detail = (False, f"generated Cypher failed: {exec_error}") if exec_error else compare(q.compare, got, want, q)

    results.add(dict(
        id=q.id, category=q.category, question=q.question, passed=passed, detail=detail,
        latency_s=res.latency_s, generated_cypher=res.cypher, answer=res.answer,
        got_rows=(got or [])[:20], want_rows=want[:20], note=q.note,
    ))

    assert passed, (
        f"{q.id} [{q.category}] {q.question}\n"
        f"  compare={q.compare}: {detail}\n"
        f"  generated cypher:\n{res.cypher}\n"
        f"  expected cypher:\n{q.expected_cypher}\n"
        f"  answer: {res.answer}"
    )
