import pytest

from harness import CFG, Graph, Results, load_questions


def pytest_addoption(parser):
    parser.addoption("--no-api", action="store_true", default=False,
                     help="Skip the chat API; only validate that ground-truth Cypher runs (tests questions.yaml itself).")
    parser.addoption("--category", action="store", default=None,
                     help="Run only questions in this category (policy, claims, fraud, motor, health, ...).")
    parser.addoption("--ids", action="store", default=None,
                     help="Comma-separated question ids to run, e.g. Q01,Q19,Q34")


def pytest_generate_tests(metafunc):
    if "q" in metafunc.fixturenames:
        qs = load_questions()
        cat = metafunc.config.getoption("--category")
        ids = metafunc.config.getoption("--ids")
        if cat:
            qs = [q for q in qs if q.category == cat]
        if ids:
            wanted = {i.strip() for i in ids.split(",")}
            qs = [q for q in qs if q.id in wanted]
        metafunc.parametrize("q", qs, ids=[f"{q.id}-{q.category}" for q in qs])


@pytest.fixture(scope="session")
def graph():
    g = Graph(CFG)
    yield g
    g.close()


@pytest.fixture(scope="session")
def results():
    r = Results()
    yield r
    r.write_summary()
    print(f"\nSummary written to {r.summary}")


@pytest.fixture(scope="session")
def no_api(request):
    return request.config.getoption("--no-api")
