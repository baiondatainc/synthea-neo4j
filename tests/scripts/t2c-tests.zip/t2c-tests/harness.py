"""Shared helpers for the text2cypher regression suite.

Adapt `ask_chat()` to your chat backend - everything else is generic.
"""
from __future__ import annotations

import datetime as dt
import decimal
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests
import yaml
from neo4j import GraphDatabase

ROOT = Path(__file__).parent
QUESTIONS_FILE = ROOT / "questions.yaml"
RESULTS_DIR = ROOT / "results"


# ---------------------------------------------------------------------------
# Config (env vars)
# ---------------------------------------------------------------------------
@dataclass
class Config:
    api_url: str = os.getenv("T2C_API_URL", "http://localhost:8000/ask")
    api_key: str = os.getenv("T2C_API_KEY", "")
    api_timeout: int = int(os.getenv("T2C_API_TIMEOUT", "120"))
    neo4j_uri: str = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user: str = os.getenv("NEO4J_USER", "neo4j")
    neo4j_password: str = os.getenv("NEO4J_PASSWORD", "password")
    neo4j_database: str = os.getenv("NEO4J_DATABASE", "neo4j")
    # response-field names returned by your chat API
    field_cypher: str = os.getenv("T2C_FIELD_CYPHER", "cypher")
    field_rows: str = os.getenv("T2C_FIELD_ROWS", "rows")
    field_answer: str = os.getenv("T2C_FIELD_ANSWER", "answer")


CFG = Config()


# ---------------------------------------------------------------------------
# Question loading
# ---------------------------------------------------------------------------
@dataclass
class Question:
    id: str
    category: str
    question: str
    compare: str
    expected_cypher: str
    tolerance: float = 0.01
    round_to: int = 2
    topk: int = 10
    note: str = ""
    raw: dict = field(default_factory=dict)


_PLACEHOLDER = re.compile(r"\$\{(\w+)\}")


def _fill(text: str, values: dict[str, Any]) -> str:
    def rep(m):
        k = m.group(1)
        if k not in values:
            raise KeyError(f"placeholder ${{{k}}} not defined in questions.yaml values")
        return str(values[k])
    return _PLACEHOLDER.sub(rep, text)


def load_questions(path: Path = QUESTIONS_FILE) -> list[Question]:
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    values = doc.get("values", {})
    defaults = doc.get("defaults", {})
    out = []
    for q in doc["questions"]:
        out.append(Question(
            id=q["id"],
            category=q.get("category", "misc"),
            question=_fill(q["question"], values),
            compare=q.get("compare", "rows"),
            expected_cypher=_fill(q["expected_cypher"], values).strip(),
            tolerance=float(q.get("tolerance", defaults.get("tolerance", 0.01))),
            round_to=int(q.get("round_to", defaults.get("round_to", 2))),
            topk=int(q.get("topk", 10)),
            note=q.get("note", ""),
            raw=q,
        ))
    return out


# ---------------------------------------------------------------------------
# Neo4j
# ---------------------------------------------------------------------------
class Graph:
    def __init__(self, cfg: Config = CFG):
        self.driver = GraphDatabase.driver(cfg.neo4j_uri, auth=(cfg.neo4j_user, cfg.neo4j_password))
        self.db = cfg.neo4j_database

    def run(self, cypher: str, **params) -> list[dict]:
        with self.driver.session(database=self.db) as s:
            return [r.data() for r in s.run(cypher, **params)]

    def close(self):
        self.driver.close()


# ---------------------------------------------------------------------------
# Chat API adapter  <-- the only function you should need to change
# ---------------------------------------------------------------------------
@dataclass
class ChatResult:
    cypher: str | None
    rows: list[dict] | None
    answer: str | None
    raw: Any
    latency_s: float


def ask_chat(question: str, cfg: Config = CFG) -> ChatResult:
    """POST {question} to the chat backend. Expected JSON response (any subset):
        {"cypher": "...", "rows": [{...}], "answer": "..."}
    If only `cypher` is returned, the harness executes it against Neo4j itself.
    """
    import time
    headers = {"Content-Type": "application/json"}
    if cfg.api_key:
        headers["Authorization"] = f"Bearer {cfg.api_key}"
    t0 = time.perf_counter()
    r = requests.post(cfg.api_url, json={"question": question}, headers=headers, timeout=cfg.api_timeout)
    latency = time.perf_counter() - t0
    r.raise_for_status()
    body = r.json()
    return ChatResult(
        cypher=body.get(cfg.field_cypher),
        rows=body.get(cfg.field_rows),
        answer=body.get(cfg.field_answer),
        raw=body,
        latency_s=latency,
    )


# ---------------------------------------------------------------------------
# Normalisation + comparison (column-name and column-order agnostic)
# ---------------------------------------------------------------------------
def _norm_value(v: Any, round_to: int) -> Any:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float, decimal.Decimal)):
        f = float(v)
        return round(f, round_to)
    if isinstance(v, (dt.date, dt.datetime)):
        return v.isoformat()
    # neo4j temporal types
    if hasattr(v, "iso_format"):
        return v.iso_format()
    if hasattr(v, "to_native"):
        return _norm_value(v.to_native(), round_to)
    if isinstance(v, dict):
        return json.dumps({k: _norm_value(x, round_to) for k, x in sorted(v.items())}, sort_keys=True, default=str)
    if isinstance(v, (list, tuple)):
        return json.dumps(sorted((_norm_value(x, round_to) for x in v), key=str), default=str)
    return str(v).strip().lower()


def _row_sig(row: dict, round_to: int) -> tuple:
    """Signature independent of column names and order."""
    return tuple(sorted((str(_norm_value(v, round_to)) for v in row.values()), key=str))


def _numeric_close(a: Any, b: Any, tol: float) -> bool:
    try:
        return abs(float(a) - float(b)) <= tol
    except (TypeError, ValueError):
        return False


def _first_number(rows: list[dict]) -> float | None:
    for row in rows[:1]:
        for v in row.values():
            if isinstance(v, (int, float, decimal.Decimal)) and not isinstance(v, bool):
                return float(v)
    return None


def compare(mode: str, got: list[dict], want: list[dict], q: Question) -> tuple[bool, str]:
    """Return (passed, message)."""
    got = got or []
    want = want or []

    if mode == "nonempty":
        return (len(got) > 0, f"got {len(got)} rows")

    if mode == "count":
        g, w = _first_number(got), _first_number(want)
        if g is None:
            return (False, f"no numeric value in response; rows={got[:3]}")
        ok = _numeric_close(g, w, q.tolerance)
        return (ok, f"got {g} want {w} (tol {q.tolerance})")

    if mode == "value":
        if len(got) != 1 or len(want) != 1:
            return (False, f"expected exactly 1 row, got {len(got)} want {len(want)}")
        gv = sorted(_norm_value(v, q.round_to) for v in got[0].values() if v is not None)
        wv = sorted(_norm_value(v, q.round_to) for v in want[0].values() if v is not None)
        if len(gv) != len(wv):
            return (False, f"value count differs: got {gv} want {wv}")
        for a, b in zip(gv, wv):
            if a == b or _numeric_close(a, b, q.tolerance):
                continue
            return (False, f"mismatch: got {gv} want {wv}")
        return (True, "ok")

    if mode == "topk":
        k = q.topk
        # key = first column of each expected row; compare ordered list of keys
        want_keys = [_norm_value(next(iter(r.values())), q.round_to) for r in want[:k]]
        # for the response we don't know which column is the key: accept if any
        # column, read top-k, reproduces the ordered key list
        if not got:
            return (False, "empty response")
        cols = list(got[0].keys())
        for c in cols:
            got_keys = [_norm_value(r.get(c), q.round_to) for r in got[:k]]
            if got_keys == want_keys:
                return (True, f"ordered top-{k} match on column '{c}'")
        return (False, f"no column reproduces top-{k} keys {want_keys}; got first row {got[0]}")

    if mode == "rows":
        gs = sorted(_row_sig(r, q.round_to) for r in got)
        ws = sorted(_row_sig(r, q.round_to) for r in want)
        if gs == ws:
            return (True, f"{len(ws)} rows match")
        # tolerant numeric pass: try to pair rows
        if len(gs) != len(ws):
            return (False, f"row count differs: got {len(gs)} want {len(ws)}")
        unmatched = []
        pool = list(gs)
        for w in ws:
            hit = None
            for g in pool:
                if len(g) == len(w) and all(a == b or _numeric_close(a, b, q.tolerance) for a, b in zip(g, w)):
                    hit = g
                    break
            if hit is None:
                unmatched.append(w)
            else:
                pool.remove(hit)
        if not unmatched:
            return (True, f"{len(ws)} rows match within tolerance")
        return (False, f"{len(unmatched)} unmatched expected rows, e.g. {unmatched[:2]}; extra got e.g. {pool[:2]}")

    return (False, f"unknown compare mode {mode}")


# ---------------------------------------------------------------------------
# Results sink
# ---------------------------------------------------------------------------
class Results:
    def __init__(self):
        RESULTS_DIR.mkdir(exist_ok=True)
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.jsonl = RESULTS_DIR / f"run-{stamp}.jsonl"
        self.summary = RESULTS_DIR / f"run-{stamp}.md"
        self.records: list[dict] = []

    def add(self, rec: dict):
        self.records.append(rec)
        with self.jsonl.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")

    def write_summary(self):
        if not self.records:
            return
        total = len(self.records)
        passed = sum(1 for r in self.records if r["passed"])
        by_cat: dict[str, list[int]] = {}
        for r in self.records:
            by_cat.setdefault(r["category"], [0, 0])
            by_cat[r["category"]][1] += 1
            if r["passed"]:
                by_cat[r["category"]][0] += 1
        lines = [f"# text2cypher run - {passed}/{total} passed ({100*passed/total:.0f}%)", ""]
        lines += ["| category | passed | total |", "|---|---|---|"]
        lines += [f"| {c} | {p} | {t} |" for c, (p, t) in sorted(by_cat.items())]
        lines += ["", "| id | result | latency s | question | detail |", "|---|---|---|---|---|"]
        for r in self.records:
            lines.append(f"| {r['id']} | {'PASS' if r['passed'] else 'FAIL'} | {r.get('latency_s', 0):.1f} | "
                         f"{r['question']} | {str(r['detail']).replace('|', '/')[:160]} |")
        self.summary.write_text("\n".join(lines), encoding="utf-8")
